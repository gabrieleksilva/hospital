import './../Administrador/Administrador.css';
import Header from './../../components/Header';
import React, { useEffect, useState } from 'react';

export default function Administrador() {
  return (
    <div>
      <Header />
      <main>
        {ListaDeUsuarios()}
      </main>
    </div>
  );
}


function ListaDeUsuarios() {

  const [users, setUsers] = useState([]);

  // Função que faz a requisição para buscar os usuários
  const fetchUsers = async () => {
    const response = await fetch('http://localhost:3001/buscaUsuario', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.ok) {
      const data = await response.json();
      setUsers(data); // Atualiza o estado com os dados recebidos
    }
  };

  // useEffect que executa a função fetchUsers quando o componente é montado
  useEffect(() => {
    fetchUsers(); // Chama a função de busca automaticamente
  }, []);
  const handleButtonClick = () => {
    window.location.href = 'http://localhost:3000/cadastro';
  };
  return (
    <div className='header'>
      <div className='title'>
        <h1>Lista de Usuários</h1>
      </div>
      <table>
        <thead>
          <tr>
            <th className="column">ID</th>
            <th className="column">Imagem</th>
            <th className="column">Nome</th>
            <th className="column">Email</th>
            <th className="column">Nivel</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td className="column">{user.id}</td>
              <td className="column">
                {user.imagem ? (
                  <img
                    src={user.imagem}
                    alt={`Imagem de ${user.name}`}
                    style={{ width: '50px', height: '50px', borderRadius: '5px' }}
                  />
                ) : (
                  'Sem imagem'
                )}
              </td>
              <td className="column">{user.name}</td>
              <td className="column">{user.email}</td>
              <td className="column">{user.nivel}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className='buttonCadastrar' onClick={handleButtonClick}>Cadastrar</button>
    </div>
  );
}
