import './../Cadastro/Cadastro.css';
import Header from './../../components/Header';
import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Cadastro() {
  return (
    <div>
      <Header />
      <main>
        {CadastrarUsuario()}
      </main>
    </div>
  );
}

function CadastrarUsuario() {

  const [password, setPassword] = useState('');
  const [nivel, setNivel] = useState('');
  const [imagem, setImagem] = useState([]);
  var [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [tipoImagem, setTipoImagem] = useState('');
  const [imagemCadastrada, setImagemCadastrada] = useState('');



  // Função que faz a requisição para buscar os usuários
  const fetchUsers = async () => {
    const response = await fetch('http://localhost:3001/buscaUsuario', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (response.ok) {
      const data = await response.json();
      users = data;
    };// Atualiza o estado com os dados recebidos
    const newUser = {
      id: users.length + 1,  // Cria um ID incremental
      name: name,
      email: email,
      password: password,
      nivel: nivel,
      imagem: imagemCadastrada,
    };
    setUsers([...users, newUser]);
  };

  // sempre que houver uma atualizacao na lista de usuario ele cadastra essa nova pessoa
  useEffect(() => {
    if (users.length !== 0) {
      fetchData(users);
    }
  }, [users]);

  // Função para adicionar buscar a lista de usuarios
  const handleSaveFile = async (e) => {
    fetchUsers();
  };

  async function fetchData(usuarios) {
    await fetch('http://localhost:3001/cadastrarUser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(usuarios) // Envia os dados para o back-end 
    });
  }


  const fetchPexelsData = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.get(`https://api.pexels.com/v1/search?query=${tipoImagem}&per_page=10`, {
        headers: {
          Authorization: 'm2yadIt05uEC0lEdLTa67jAFLo1ZSQMbKivrTtcJKMcHbTwdSou2yHm1',
        },
      });
      setImagem(response.data.photos);
    } catch (error) {
      console.error('Erro ao buscar dados da API Pexels:', error);
    }
  };


  return (
    <div>
      <div className='telaCadastro'>
        <h1>Cadastro</h1>
      </div>
      <div className='telaCadastro'>
        <form>
          <fieldset>
            <label htmlFor="fname">Nome completo:</label>
            <input type="text" id="name" name="name" value={name}
              onChange={(e) => setName(e.target.value)} /><br></br>
            <label htmlFor="lemail">Usuário:</label>
            <input type="email" id="email" name="email" value={email}
              onChange={(e) => setEmail(e.target.value)} /><br></br><br></br>
            <label htmlFor="lpassword">Senha:</label>
            <input type="password" id="password" name="password" value={password}
              onChange={(e) => setPassword(e.target.value)} /><br></br><br></br>

            <select value={tipoImagem} onChange={(e) => setTipoImagem(e.target.value)}>
              <option value="">Imagem</option>
              <option value="nature">Natureza</option>
              <option value="pears">Peras</option>
              <option value="tigers">Tigres</option>
              <option value="ocean">Oceanos</option>
            </select>
            <button className='buttonSalvar' type='submit' onClick={fetchPexelsData}>Pesquisar</button><br></br>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginTop: '20px' }}>
              {imagem.map((photo) => (
                <img
                  key={photo.id}
                  src={photo.src.medium}
                  alt={photo.alt || 'Imagem'}
                  style={{ width: '200px', height: 'auto', borderRadius: '10px' }}
                  onClick={() => setImagemCadastrada(photo.src.medium)} // Salva a URL da imagem
                />
              ))}
            </div>


            <select value={nivel} onChange={(e) => setNivel(e.target.value)}>
              <option value="">Nível</option>
              <option value="paciente">Paciente</option>
              <option value="medico">Médico</option>
              <option value="admin">Administrador</option>
            </select><br></br>
            <button className='buttonSalvar' type='submit' onClick={handleSaveFile}>Salvar</button>
            <button className='buttonVoltar' type='button'>Cancelar</button>
          </fieldset>
        </form>
      </div>
    </div>
  )
}

