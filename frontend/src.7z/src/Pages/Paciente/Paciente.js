import './../Paciente/Paciente.css';
import React, { useEffect, useState } from 'react';
import Header from './../../components/Header';

export default function Paciente() {

  return (
    <div>
      <Header />
      <main>
        {CadastroDeConsulta()}
      </main>
    </div>
  );
}
function CadastroDeConsulta() {
  const [exame, setExame] = useState('');
  const [observacao, setObservacao] = useState('');
  const [dataNasc, setDt] = useState('');
  var [pacientes, setPacientes] = useState([]);
  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');

  const [cep, setCep] = useState('');
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);


  // Função que faz a requisição para buscar
  const fetchPacientes = async () => {
    const response = await fetch('http://localhost:3001/buscaPaciente', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (response.ok) {
      const data = await response.json();
      pacientes = data;
    };// Atualiza o estado com os dados recebidos
    const newPac = {
      name: name,
      cpf: cpf,
      dataNasc: dataNasc,
      observacao: observacao,
      exame: exame,
      localizacao: data,

    }
    setPacientes([...pacientes, newPac]);
  };

  // sempre que houver uma atualizacao na lista de paciente ele cadastra essa nova pessoa
  useEffect(() => {
    if (pacientes.length !== 0) {
      fetchData(pacientes);
    }
  }, [pacientes]);

  // Função para adicionar buscar a lista de pacientes
  const handleSaveFile = async (e) => {
    fetchPacientes();
  };


  async function fetchData(pacientes) {
    await fetch('http://localhost:3001/cadastrarPaciente', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pacientes) // Envia os dados para o back-end 
    });
  }


  
  const handleFetch = async (e) => {
    e.preventDefault();
    setError(null); // Limpa o erro anterior
    setData(null); // Limpa os dados anteriores

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      if (!response.ok) {
        throw new Error('CEP não encontrado');
      }
      const jsonData = await response.json();
      setData(jsonData);
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <div>
      <div className='telaPaciente'>
        <h1>Paciente</h1>
      </div>
      <div className='telaPaciente'>
        <form>
          <fieldset>
            <legend>Paciente:</legend>
            <label htmlFor="fname">Nome completo:</label>
            <input type="text"
              id="name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)} /><br></br>
            <label htmlFor="lcpf">CPF:</label>
            <input type="text" id="lcpf" name="lcpf" value={cpf}
              onChange={(e) => setCpf(e.target.value)} /><br></br>

            <label htmlFor="lcep">CEP:</label>
            <input
              type="text"
              value={cep}
              onChange={(e) => setCep(e.target.value)}
              placeholder="Digite o CEP"
            />
            <button onClick={handleFetch}>Buscar</button>
            {/* <button onClick={() => }>Buscar</button> */}

            {error && <div style={{ color: 'red' }}>Erro: {error}</div>}
            {data && (
              <div>
                <h2>Endereço:</h2>
                <p>Rua: {data.logradouro}</p>
                <p>Bairro: {data.bairro}</p>
                <p>Cidade: {data.localidade}</p>
                <p>Estado: {data.uf}</p>
              </div>
            )}

            <label htmlFor="birthday">Data de nascimento:</label>
            <input type="date" id="birthday" name="birthday" value={dataNasc}
              onChange={(e) => setDt(e.target.value)} /><br></br>
            <h2>Exame:</h2>
            <textarea placeholder="Coloque o resultado do exame aqui..." rows="5" cols="50" value={exame}
              onChange={(e) => setExame(e.target.value)} />
            <br></br>
            <h2>Observações:</h2>
            <textarea placeholder="Alergia, doença crônica etc..." rows="5" cols="50" value={observacao}
              onChange={(e) => setObservacao(e.target.value)} />
            <br></br>
            <button className='buttonSalvar' type='submit' onClick={handleSaveFile}>Salvar</button>
          </fieldset>
        </form>
      </div>
    </div>
  )
}