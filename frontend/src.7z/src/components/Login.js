import { useState } from "react";
import { useNavigate } from "react-router-dom";
import './../App.css';
export default function Login() {

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  

  const handleLogin = async (e) => {
    e.preventDefault();
    
  // Enviar os dados para o servidor
  const response = await fetch('http://localhost:3001/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password })  // Envia os dados para o back-end
  });
  if(response.status === 200){
    const data = await response.json();

    switch (data) {
      case 'admin':
        navigate('/admin');
        break;
      case 'paciente':
        navigate('/paciente');
        break;
      default:
        navigate('/medico');
        break;
    }
  }
};

  return (
    <div className='login-form-wrap'>
      <h2>Login</h2>
      <form className='login-form'>
        <input className="inputLogin" type='email' 
               name='email' 
               placeholder='Email' required
               onChange={(e) => setEmail(e.target.value)}></input>
        <input className="inputLogin" type='password' 
               name='password' 
               placeholder='Password' required
               onChange={(e) => setPassword(e.target.value)}></input>
          
        <button type='submit'
                className='btn-login'
                onClick={(e) => handleLogin(e)}>Login</button>
                
      </form>
    </div>
  );
}
