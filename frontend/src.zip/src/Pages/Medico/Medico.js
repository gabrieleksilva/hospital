import './Medico.css';
import React, {useEffect } from 'react';
import Header from './../../components/Header';
export default function Medico() {
  return(
    <div>
      <Header/>
      <main>
        <h1 className="medico">Medico</h1>
        {ListaDeDisciplinas()}
      </main>
    </div>
  );
}


function ListaDeDisciplinas() {
  return (
    <div>
        <h2>Atendimento</h2>
        <form>
                <fieldset>
                    <legend>Paciente:</legend>
                        <label for="fname">Nome completo:</label>
                        <input type="text" id="fname" name="fname" value={"Neymar Junior"} readOnly/><br></br>
                        
                        <label for="birthday">Data de nascimento:</label>
                        <input type="date" id="birthday" name="birthday"/><br></br>
                        <h2>Resultado do exame:</h2>
                        { <textarea
                        value="paciente grave"
                        //onChange={(e) => setText(e.target.value)}
                        rows="10"
                        cols="50"
                        /> }
                        {/* <button onClick={handleSaveFile}>Salvar</button> */}
                    </fieldset>
            </form>
    </div>
    
    
  )
}