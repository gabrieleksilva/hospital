import './../Medico/Medico.css';
import React, {useEffect } from 'react';
export default function Paciente() {

  //para listar pegando os dados do back
  // useEffect(() => {
  //   loadCustomers();
  // }, [])

  // async function loadCustomers() {
  //   const response = await routes.get("/customer")
  //   console.log(response)
  // }

  
  return (
    <div className='medico'>
        <h1>Paciente</h1>
        <h2>paciente</h2>
        <form>
                <fieldset>
                    <legend>Paciente:</legend>
                        <label for="fname">Nome completo:</label>
                        <input type="text" id="fname" name="fname" value={"ola"} readOnly/><br></br>
                        <label for="lname">Sobrenome:</label>
                        <input type="text" id="lname" name="lname"/><br></br>
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email"/><br></br>
                        <label for="birthday">Data de nascimento:</label>
                        <input type="date" id="birthday" name="birthday"/><br></br>
                        <h2>Observações:</h2>
                        {/* <textarea 
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        rows="10"
                        cols="50"
                        /> */}
                        {/* <button onClick={handleSaveFile}>Salvar</button> */}
                    </fieldset>
                    
                
            </form>
            
    </div>
    
    
  )
}
