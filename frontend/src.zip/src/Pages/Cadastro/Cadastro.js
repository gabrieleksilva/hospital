import './../Cadastro/Cadastro.css';
import React, { useEffect, useState} from 'react';
import { saveAs } from 'file-saver';

export default function Cadastro() {

 // Estado para armazenar na lista de disciplinas e a nova disciplina
 const [email, setEmail] = useState('');
 const [password, setPassword] = useState('');
 const [name, setName] = useState('');
 const [nivel, setNivel] = useState('');


 const handleSaveFile = () =>{
   const fileContent = `Email:\n${email}\n\nName:\n${password}\n\nNivel: ${nivel}\n\nName:\n${name}`;
   const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
   saveAs(blob, 'arquivo.txt');
};


  return (
    <div>
      <h1>Cadastro</h1>
      <form>
        <fieldset>
          <label htmlFor="fname">Nome completo:</label>
          <input type="text" id="name" name="name" 
          onChange={(e) => setName(e.target.value)} /><br></br>
          <label htmlFor="lemail">Usuário:</label>
          <input type="email" id="email" name="email" 
          onChange={(e) => setEmail(e.target.value)} /><br></br>
          <label htmlFor="lpassword">Senha:</label>
          <input type="password" id="password" name="password"
          onChange={(e) => setPassword(e.target.value)} /><br></br>
          
            <select value={nivel} onChange={(e) => setNivel(e.target.value)}>
              <option value="">Nível</option>
              <option value="paciente">Paciente</option>
              <option value="medico">Médico</option>
              <option value="administrador">Administrador</option>
          </select><br></br>

          <button onClick={handleSaveFile}>Salvar</button>
          
        </fieldset>
      </form>
    </div>

  )
}

