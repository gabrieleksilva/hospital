import './App.css';
import Login from './components/Login';
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Medico from './Pages/Medico/Medico';
import Paciente from './Pages/Paciente/Paciente';
import Cadastro from './Pages/Cadastro/Cadastro';
import Administrador from './Pages/Administrador/Administrador';


function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Redirecionar a rota raiz ("/") para "/login" */}
        <Route path="/" element={<Navigate to="/login" />} />
        {/* Rota para "/login" exibindo o componente Login */}
        <Route path="/login" element={<Login />} />
        <Route path="/medico" element={<Medico />} />
        <Route path="/paciente" element={<Paciente />} />
        <Route path="/cadastro" element={<Cadastro />} />
        <Route path="/admin" element={<Administrador />} />
      
      </Routes>
    </BrowserRouter>
  );
}

export default App;
