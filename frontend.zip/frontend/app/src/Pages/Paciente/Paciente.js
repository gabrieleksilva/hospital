import './../Paciente/Paciente.css';
import React, { useEffect, useState } from 'react';
import Header from './../../components/Header';
export default function Paciente() {

  return (
    <div>
      <Header />
      <main>
        {CadastroDeConsulta()}
      </main>
    </div>
  );
}
function CadastroDeConsulta() {
  const [exame, setExame] = useState('');
  const [observacao, setObservacao] = useState('');
  const [dataNasc, setDt] = useState('');
  var [pacientes, setPacientes] = useState([]);
  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');


  // Função que faz a requisição para buscar
  const fetchPacientes = async () => {
    const response = await fetch('http://localhost:3001/buscaPaciente', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (response.ok) {
      const data = await response.json();
      pacientes = data;
    };// Atualiza o estado com os dados recebidos
      const newPac = {
        name: name,
        cpf: cpf,
        dataNasc: dataNasc,
        observacao: observacao,
        exame: exame,
    }
    setPacientes([...pacientes, newPac]);
  };

  // sempre que houver uma atualizacao na lista de paciente ele cadastra essa nova pessoa
  useEffect(() => {
    if (pacientes.length !== 0) {
      fetchData(pacientes);
    }
  }, [pacientes]);

  // Função para adicionar buscar a lista de pacientes
  const handleSaveFile = async (e) => {
    fetchPacientes();
  };

  async function fetchData(pacientes) {
    await fetch('http://localhost:3001/cadastrarPaciente', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pacientes) // Envia os dados para o back-end 
    });
  }


  return (
    <div>
      <div className='telaPaciente'>
        <h1>Paciente</h1>
      </div>
      <div className='telaPaciente'>
        <form>
          <fieldset>
            <legend>Paciente:</legend>
            <label htmlFor="fname">Nome completo:</label>
            <input type="text"
              id="name"
              name="name"
              value={name}
              onChange={(e) => setName(e.target.value)} /><br></br>
            <label htmlFor="lcpf">CPF:</label>
            <input type="text" id="lcpf" name="lcpf" value={cpf}
              onChange={(e) => setCpf(e.target.value)} /><br></br>
            <label htmlFor="birthday">Data de nascimento:</label>
            <input type="date" id="birthday" name="birthday" value={dataNasc}
              onChange={(e) => setDt(e.target.value)} /><br></br>
            <h2>Exame:</h2>
            <textarea placeholder="Coloque o resultado do exame aqui..." rows="5" cols="50" value={exame}
              onChange={(e) => setExame(e.target.value)} />
            <br></br>
            <h2>Observações:</h2>
            <textarea placeholder="Alergia, doença crônica etc..." rows="5" cols="50" value={observacao}
              onChange={(e) => setObservacao(e.target.value)} />
            <br></br>
            <button className='buttonSalvar' type='submit' onClick={handleSaveFile}>Salvar</button>
          </fieldset>
        </form>
      </div>
    </div>
  )
}