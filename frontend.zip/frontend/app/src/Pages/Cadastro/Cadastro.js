import './../Cadastro/Cadastro.css';
import Header from './../../components/Header';
import React, { useEffect, useState } from 'react';

export default function Cadastro() {
  return (
    <div>
      <Header />
      <main>
        {CadastrarUsuario()}
      </main>
    </div>
  );
}

function CadastrarUsuario() {

  const [password, setPassword] = useState('');
  const [nivel, setNivel] = useState('');
  var [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');


  // Função que faz a requisição para buscar os usuários
  const fetchUsers = async () => {
    const response = await fetch('http://localhost:3001/buscaUsuario', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.ok) {
      const data = await response.json();
      users = (data)

    }
    const newUser = {
      id: users.length + 1,  // Cria um ID incremental
      name: name,
      email: email,
      password: password,
      nivel: nivel,
    };

    setUsers([...users, newUser]); // Atualiza o array de usuários com o novo usuário
  };

  useEffect(() => {
    if (users.length !== 0) {// se a lista de users estiver preenchida ele pode adicionar outro user
      fetchData(users);
    }
  }, [users]);

  // Função para adicionar um novo usuário
  const handleSaveFile = async (e) => {
    fetchUsers();
  };

  async function fetchData(users) {
    await fetch('http://localhost:3001/cadastrarUser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(users) // Envia os dados para o back-end
    });
  }

  return (
    <div>
      <div className='telaCadastro'>
        <h1>Cadastro</h1>
      </div>
      <div className='telaCadastro'>
        <form>
          <fieldset>
            <label htmlFor="fname">Nome completo:</label>
            <input type="text" id="name" name="name" value={name}
              onChange={(e) => setName(e.target.value)} /><br></br>
            <label htmlFor="lemail">Usuário:</label>
            <input type="email" id="email" name="email" value={email}
              onChange={(e) => setEmail(e.target.value)} /><br></br><br></br>
            <label htmlFor="lpassword">Senha:</label>
            <input type="password" id="password" name="password" value={password}
              onChange={(e) => setPassword(e.target.value)} /><br></br><br></br>
            <select value={nivel} onChange={(e) => setNivel(e.target.value)}>
              <option value="">Nível</option>
              <option value="paciente">Paciente</option>
              <option value="medico">Médico</option>
              <option value="admin">Administrador</option>
            </select><br></br>
            <button className='buttonSalvar' type='submit' onClick={handleSaveFile}>Salvar</button>
            <button className='buttonVoltar' type='button'>Cancelar</button>
          </fieldset>
        </form>
      </div>
    </div>
  )
}

