import './Medico.css';
import React, { useEffect, useState } from 'react';
import Header from './../../components/Header';
export default function Medico() {
  return (
    <div>
      <Header />
      <main>
        <h1 className="medico">Medico</h1>
        {ListaDePacientes()}
      </main>
    </div>
  );
}


function ListaDePacientes() {
  const [pacientes, setPacientes] = useState([]);

  const fetchPacientes = async () => {
    const response = await fetch('http://localhost:3001/buscaPaciente', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.ok) {
      const data = await response.json();
      setPacientes(data); // Atualiza o estado com os dados recebidos
    }
  };

  const handleDelete = async (cpf) => {
    try {
      const response = await fetch(`http://localhost:3001/deletePaciente/${cpf}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Atualiza a tabela removendo o paciente
        setPacientes(pacientes.filter((paciente) => paciente.cpf !== cpf));
      } else {
        console.error('Erro ao deletar o paciente');
      }
    } catch (error) {
      console.error('Erro na requisição', error);
    }
  };

  // useEffect que executa a função fetchPacientes quando o componente é montado
  useEffect(() => {
    fetchPacientes(); // Chama a função de busca automaticamente
  }, []);

  return (
    <div className='header-medico'>
      <div className='title-medico'>
        <h1>Lista de Pacientes</h1>
      </div>
      <table>
        <thead>
          <tr>
            <th className="column">Nome</th>
            <th className="column">CPF</th>
            <th className="column">Data de nascimento</th>
            <th className="column">Observação</th>
            <th className="column">Exame</th>
            <th className="column">Consultar</th>
          </tr>
        </thead>
        <tbody>
          {pacientes.map(paciente => (
            <tr key={paciente.cpf}>
              <td className="column">{paciente.name}</td>
              <td className="column">{paciente.cpf}</td>
              <td className="column">{paciente.dataNasc}</td>
              <td className="column">{paciente.observacao}</td>
              <td className="column">{paciente.exame}</td>
              <td className="column">
                <button className='buttonExaminar' onClick={() => handleDelete(paciente.cpf)}>Examinado</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>


  )
}