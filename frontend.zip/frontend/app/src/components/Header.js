import React from "react";
import './../App.css';


export default function Header(){
    return(
        <header className="App-header">
            <h1>Hospital IFSP</h1>
        </header>
    );
}